# -*- coding: utf-8 -*-
"""
云端通信

两种传输方式，程序自动选：

  方式一（推荐）服务端 API
      先拿 access_token，再调 tcb/invokecloudfunction 直接执行云函数。
      不需要 HTTP 网关、不需要域名、不需要备案，免费环境就能用。
      云函数那边一个字都不用改 —— 收到的参数结构和以前完全一样。

  方式二 HTTP 访问服务
      直接 POST 到云函数的公网地址。需要环境的 HTTP 网关配好。
      当前免费体验版控制台里没有这个入口，暂时用不了。

两种都没配 → 本地运行模式，数据不上报（调试时能用）

断网处理：上报失败存到本地队列（pending.json），下次成功时补发。
老人家里断网是常事，服药记录不能因此丢掉。
"""

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

import config

PENDING_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pending.json')
MAX_PENDING = 200

# 一条积压记录最多补发几次。超过就放弃并大声报错 ——
# 永久性错误（比如 token 配错）重试多少次都不会成功，
# 无限重试只会让队列涨到上限、掩盖真正的问题。
MAX_FLUSH_ATTEMPTS = 8

# 微信服务端 API 的根地址
WX_API = 'https://api.weixin.qq.com'

# access_token 缓存。有效期 7200 秒，提前 5 分钟刷新
_token = {'value': '', 'expire_at': 0.0}
TOKEN_REFRESH_AHEAD = 300


# ══════════════════════════════════════════════════════════════
#  对外接口
# ══════════════════════════════════════════════════════════════

def is_configured():
    """配了任意一种传输方式就算已配置"""
    if config.CLOUD_BASE_URL:
        return True
    return bool(config.WX_APPID and config.WX_APPSECRET and config.CLOUD_ENV)


def transport_name():
    if config.CLOUD_BASE_URL:
        return 'HTTP 访问服务'
    if config.WX_APPSECRET:
        return '服务端 API'
    return '未配置'


def report_event(bay, event_type, timestamp=None):
    """
    上报一次服药事件。

    event_type:
        'taken'            传感器检测到取药
        'vision_confirmed' 摄像头确认药片真的被取走（可信度更高）
        'missed'           药盒本地判定漏服（提醒超时仍未取药）
        'lid_open'         仅开盖，不单独计为服药

    时间戳一律带上。不带的话云端只能按「收到请求的时刻」判定，
    断网补发时会以补发时刻生成日期 —— 夜里断网、早上补发，
    这次服药就会被记到第二天，当天那一次还会被云端补成一条假漏服。
    """
    payload = {
        'action': 'report',
        'deviceId': config.DEVICE_ID,
        'bayIndex': bay,
        'eventType': event_type,
        'token': config.DEVICE_TOKEN,
        # 事件真正发生的时刻。进了本地队列后原样保留，
        # 补发时云端仍能按正确时间判定
        'timestamp': timestamp or datetime.now(timezone.utc).isoformat(),
    }
    return _call('record', payload, queue_on_fail=True)


def heartbeat(battery=None):
    """上报心跳。间隔必须小于云端的 5 分钟在线判定窗口。"""
    payload = {
        'action': 'heartbeat',
        'deviceId': config.DEVICE_ID,
        'token': config.DEVICE_TOKEN,
    }
    if battery is not None:
        payload['battery'] = battery
    return _call('device', payload)


def fetch_plans():
    """拉取该设备的用药计划。返回计划列表，失败返回 None（调用方保留旧计划）。"""
    payload = {
        'action': 'listForDevice',
        'deviceId': config.DEVICE_ID,
        'token': config.DEVICE_TOKEN,
    }
    r = _call('plan', payload)
    if r and r.get('code') == 0:
        return r.get('data', {}).get('list', [])
    return None


# ══════════════════════════════════════════════════════════════
#  传输层
# ══════════════════════════════════════════════════════════════

_notified_unconfigured = False


def _call(name, payload, queue_on_fail=False):
    global _notified_unconfigured

    if not is_configured():
        if not _notified_unconfigured:
            print('[CLOUD] 未配置云端，本地运行模式（数据不会上传）')
            print('        配置方法见 config.py 的「云端对接」一节')
            _notified_unconfigured = True
        return None

    last_err = None
    for attempt in range(config.HTTP_RETRY):
        try:
            res = _send(name, payload)
            # 云函数把业务错误放在返回体里（HTTP 状态仍是 200）：
            # 403 鉴权失败、404 设备未注册、500 内部错误……
            # 只判断「HTTP 没报错」会把它们全当成功，记录静默消失且不入队。
            if res is None or res.get('code') != 0:
                raise RuntimeError(_describe(res))
            _flush_pending()
            return res
        except Exception as e:
            last_err = e
            if attempt < config.HTTP_RETRY - 1:
                time.sleep(1.5 * (attempt + 1))

    print(f'[CLOUD] {name} 上报失败：{last_err}')
    if queue_on_fail:
        _enqueue(payload)
    return None


def _send(name, payload):
    """按配置选择传输方式"""
    if config.CLOUD_BASE_URL:
        return _send_via_http(name, payload)
    return _send_via_api(name, payload)


def _describe(res):
    """把云函数返回的错误拼成一句人话"""
    if res is None:
        return '响应为空或不是 JSON'
    code = res.get('code')
    msg = res.get('msg', '')
    human = {
        401: '未登录（这个接口不该由设备调用）',
        403: '鉴权失败 —— 检查 config.py 的 DEVICE_TOKEN 是否和云端一致',
        404: '设备未注册 —— 先在小程序里绑定这台药盒',
    }.get(code, '')
    return f'云端返回 code={code} {msg}{"（" + human + "）" if human else ""}'.strip()


# ── 方式一：服务端 API ─────────────────────────────────────

def _send_via_api(name, payload, _retried=False):
    """
    通过 tcb/invokecloudfunction 执行云函数。

    返回的是云函数的返回值（已经解掉外层包装），
    和走 HTTP 访问服务时拿到的结构完全一样。
    """
    token = _get_access_token()
    url = (f'{WX_API}/tcb/invokecloudfunction'
           f'?access_token={urllib.parse.quote(token)}'
           f'&env={urllib.parse.quote(config.CLOUD_ENV)}'
           f'&name={urllib.parse.quote(name)}')

    raw = _post_json(url, payload)

    errcode = raw.get('errcode')
    if errcode:
        # 令牌失效 → 强制刷新一次再重试。只重试一次，避免死循环
        if errcode in (40001, 40014, 42001) and not _retried:
            print('[CLOUD] 令牌已失效，刷新后重试')
            _get_access_token(force=True)
            return _send_via_api(name, payload, _retried=True)
        raise RuntimeError(_explain_api_error(errcode, raw.get('errmsg', '')))

    # resp_data 是云函数返回值的 JSON 字符串，要解第二层
    resp_data = raw.get('resp_data')
    if isinstance(resp_data, str):
        try:
            return json.loads(resp_data)
        except json.JSONDecodeError:
            return None
    return resp_data


def _explain_api_error(errcode, errmsg):
    """服务端 API 的错误码翻译成人话"""
    known = {
        40001: 'access_token 无效（已尝试刷新仍失败）—— 检查 AppID / AppSecret 是否匹配',
        40013: 'AppID 无效 —— 检查 config.py 的 WX_APPID',
        40125: 'AppSecret 无效 —— 检查 secret.json 或环境变量',
        45009: '接口调用超过限额 —— 等一下再试',
        85088: '该 AppID 未开通云开发 —— 确认小程序后台已开通云开发，且环境属于这个 AppID',
    }
    hint = known.get(errcode)
    return f'微信接口报错 {errcode}: {errmsg}' + (f'\n        {hint}' if hint else '')


def _get_access_token(force=False):
    """
    取 access_token，带内存缓存。

    用的是 stable_token 接口，不是老的 cgi-bin/token ——
    后者的毛病是「取得新令牌会让上一个立即失效」，
    设备、小程序、调试工具之间会互相把对方的令牌踢掉，
    表现就是时好时坏的 40001。stable_token 没有这个问题。
    """
    now = time.time()
    if (not force and _token['value']
            and _token['expire_at'] - TOKEN_REFRESH_AHEAD > now):
        return _token['value']

    if not (config.WX_APPID and config.WX_APPSECRET):
        raise RuntimeError(
            'AppSecret 没配置。三种填法见 config.py：\n'
            '  1. 环境变量 ZHIHYAO_APPSECRET\n'
            '  2. 同目录下建 secret.json，内容 {"appsecret": "你的密钥"}\n'
            '  3. 直接写在 config.py（不推荐）\n'
            '  AppSecret 在 小程序后台 → 开发管理 → 开发设置 里'
        )

    data = _post_json(f'{WX_API}/cgi-bin/stable_token', {
        'grant_type': 'client_credential',
        'appid': config.WX_APPID,
        'secret': config.WX_APPSECRET,
        'force_refresh': False,
    })

    if not data.get('access_token'):
        raise RuntimeError(_explain_api_error(
            data.get('errcode'), data.get('errmsg', '取 access_token 失败')))

    _token['value'] = data['access_token']
    _token['expire_at'] = now + int(data.get('expires_in', 7200))
    print(f'[CLOUD] 已获取 access_token，{int(data.get("expires_in", 7200))} 秒后过期')
    return _token['value']


# ── 方式二：HTTP 访问服务 ──────────────────────────────────

def _send_via_http(name, payload):
    url = config.CLOUD_BASE_URL.rstrip('/') + '/' + config.CLOUD_PATHS.get(name, name)
    return _post_json(url, payload)


# ── 共用的 HTTP 客户端 ─────────────────────────────────────

def _post_json(url, payload):
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(
        url, data=body, method='POST',
        headers={'Content-Type': 'application/json; charset=utf-8'},
    )
    with urllib.request.urlopen(req, timeout=config.HTTP_TIMEOUT) as resp:
        text = resp.read().decode('utf-8')
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        raise RuntimeError(f'返回内容不是 JSON：{text[:200]}')


# ── 断网队列 ──────────────────────────────────────────────

def _load_pending():
    if not os.path.exists(PENDING_FILE):
        return []
    try:
        with open(PENDING_FILE, encoding='utf-8') as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return []


def _save_pending(items):
    try:
        with open(PENDING_FILE, 'w', encoding='utf-8') as f:
            json.dump(items, f, ensure_ascii=False)
    except OSError as e:
        print(f'[CLOUD] 本地队列写入失败：{e}')


def _enqueue(payload):
    items = _load_pending()
    items.append({'payload': payload, 'at': time.time()})
    # 只留最近的若干条，避免文件无限增长
    if len(items) > MAX_PENDING:
        items = items[-MAX_PENDING:]
    _save_pending(items)
    print(f'[CLOUD] 已存入本地队列，待联网后补发（当前 {len(items)} 条）')


def _flush_pending():
    items = _load_pending()
    if not items:
        return

    remaining = []
    sent = 0

    for item in items:
        try:
            res = _send('record', item['payload'])
            # 业务错误也算失败 —— 原先无条件算成功，
            # 会把「补发失败」的记录直接从队列删掉，永久丢失
            if res is None or res.get('code') != 0:
                raise RuntimeError(_describe(res))
            sent += 1
        except Exception as e:
            item['attempts'] = item.get('attempts', 0) + 1
            item['lastError'] = str(e)[:120]
            if item['attempts'] >= MAX_FLUSH_ATTEMPTS:
                print(f'[CLOUD] 放弃一条补发记录（已试 {item["attempts"]} 次）：{item["lastError"]}')
            else:
                remaining.append(item)

    if sent:
        print(f'[CLOUD] 补发了 {sent} 条积压记录')
    if remaining:
        _save_pending(remaining)
        if sent == 0 and len(remaining) == len(items):
            print(f'[CLOUD] {len(remaining)} 条仍未补发成功，'
                  f'最近一次原因：{remaining[-1].get("lastError", "")}')
    elif os.path.exists(PENDING_FILE):
        os.remove(PENDING_FILE)


def pending_count():
    return len(_load_pending())
