# -*- coding: utf-8 -*-
"""
智药云联 · 硬件端配置

所有需要按实际情况改的东西都集中在这个文件里。
"""

import os

# ══════════════════════════════════════════════════════════════
#  运行模式
# ══════════════════════════════════════════════════════════════

# True  = 模拟模式。不碰真实硬件，用打印代替点灯/响铃/播报。
#         元件没到货时用它开发逻辑，也能给老师演示完整流程。
# False = 真实模式。走 GPIO 和音频设备。
#
# 也可以用环境变量覆盖：ZHIHYAO_MOCK=0 python3 main.py
USE_MOCK = os.environ.get('ZHIHYAO_MOCK', '1') != '0'


# ══════════════════════════════════════════════════════════════
#  设备身份
# ══════════════════════════════════════════════════════════════

# 药盒编号。要和云端 devices 集合里的 deviceId 一致
DEVICE_ID = os.environ.get('ZHIHYAO_DEVICE_ID', 'BOX-TEST01')

# 设备上报用的令牌。必须和云函数 record 里的 DEVICE_TOKEN 一致
# ⚠️ 这只是中期阶段的占位方案。正式做法是设备端用密钥签名，服务端验签
DEVICE_TOKEN = os.environ.get('ZHIHYAO_DEVICE_TOKEN', 'zhihyao-dev-token')


# ══════════════════════════════════════════════════════════════
#  云端对接
# ══════════════════════════════════════════════════════════════
#
# 两种方式，程序自动选：
#
#   方式一（推荐）：服务端 API —— 直接调云函数，不需要 HTTP 网关。
#                   免费、免域名、免备案，免费环境就能用。
#                   需要填 WX_APPSECRET。
#
#   方式二：HTTP 访问服务 —— 需要云开发环境的 HTTP 网关。
#           当前免费体验版控制台里没有这个入口，暂时用不了。
#           等以后能用了，把 CLOUD_BASE_URL 填上即可自动切换。
#
# 两者都不填 → 程序进入本地运行模式，数据不上传（调试时能用）

# 小程序 AppID。不是机密（任何人用你们的小程序都能看到）
WX_APPID = os.environ.get('ZHIHYAO_APPID', 'wx397363c4f4b4151d')

# 云开发环境 ID。也不是机密，写在小程序代码里
CLOUD_ENV = os.environ.get('ZHIHYAO_ENV', 'cloud1-d4gkyr16k10bd7e23')

# ⚠️ AppSecret 是小程序的最高权限钥匙，绝不能提交到 git。
#    三种填法，任选一种：
#      1. 环境变量 ZHIHYAO_APPSECRET
#      2. 同目录下的 secret.json：{"appsecret": "xxx"}（已在 .gitignore 里）
#      3. 直接写在这里（不推荐，除非你确定仓库不会公开）
WX_APPSECRET = os.environ.get('ZHIHYAO_APPSECRET', '')

_SECRET_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'secret.json')
if not WX_APPSECRET and os.path.exists(_SECRET_FILE):
    try:
        import json as _json
        with open(_SECRET_FILE, encoding='utf-8') as _f:
            WX_APPSECRET = (_json.load(_f) or {}).get('appsecret', '')
    except (OSError, ValueError):
        pass

# 方式二用：HTTP 访问服务的公网地址。留空则走方式一
CLOUD_BASE_URL = os.environ.get('ZHIHYAO_CLOUD_URL', '')

# 方式二用：各功能对应的云函数路径
CLOUD_PATHS = {
    'record': 'record',      # 上报服药事件
    'device': 'device',      # 心跳、药仓配置
    'plan':   'plan',        # 拉取用药计划
}

# 单次 HTTP 请求超时（秒）
HTTP_TIMEOUT = 8

# 上报失败时的重试次数
HTTP_RETRY = 3


# ══════════════════════════════════════════════════════════════
#  GPIO 引脚
# ══════════════════════════════════════════════════════════════
#
# 🔴 重要：下面的编号是【占位值】，必须按实际情况改！
#
#    Orange Pi 4 Pro 的 40-pin 定义和树莓派【不一样】，
#    接错 5V 会直接烧板子。
#
#    请到香橙派官网下载 Orange Pi 4 Pro 的引脚定义图，
#    对照着把下面的编号换成真实的 GPIO 线号（line number）。
#
#    然后用 tools/test_gpio.py 逐个验证 —— 接线前务必先跑这个脚本。
#
# 编号规则：填 gpiod 的【line number】（gpioinfo 输出里的第一列），
#          不是物理引脚序号，也不是 BCM 编号。

# 药仓 LED：每个药仓一颗。索引 0..5 对应 1..6 号仓
LED_PINS = [1, 2, 3, 4, 5, 6]

# 蜂鸣器（有源）
BUZZER_PIN = 7

# 确认按键
BUTTON_PIN = 8

# 药仓开盖检测（霍尔传感器 A3144E）。索引 0..5 对应 1..6 号仓
# ⚠️ A3144E 是【单极】霍尔，只对特定磁极响应。装的时候要试磁铁方向
LID_PINS = [9, 10, 11, 12, 13, 14]

# 霍尔传感器的有效电平。开盖时读到 True 还是 False，取决于接线
# （A3144E 是开漏输出，磁铁靠近时拉低电平 → 这里填 False）
LID_ACTIVE_LOW = True

# 实际使用的药仓数量（基础版 4，专业版 6）
BAY_COUNT = 6


# ══════════════════════════════════════════════════════════════
#  摄像头
# ══════════════════════════════════════════════════════════════

CAMERA_DEVICE = int(os.environ.get('ZHIHYAO_CAMERA', '0'))
CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480

# 拍一张之后要等多久让画面稳定（秒）
CAMERA_WARMUP = 1.5


# ══════════════════════════════════════════════════════════════
#  音频
# ══════════════════════════════════════════════════════════════

# 语音合成。留空则自动探测：espeak-ng → espeak → 都没有就不出声
TTS_COMMAND = os.environ.get('ZHIHYAO_TTS', 'espeak-ng')

# 语速（espeak 的字/分钟）。计划书要求 120~150，取中间值
TTS_SPEED = 135

# 预录语音目录。如果这里存在对应文件，优先播放录音而不是合成，
# 音质更好也更像真人 —— 对应计划书里的 DFPlayer 方案
VOICE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'voices')


# ══════════════════════════════════════════════════════════════
#  业务参数
# ══════════════════════════════════════════════════════════════

# 心跳间隔（秒）。必须小于云端的在线判定窗口（5 分钟），
# 否则会出现"设备活着但显示离线"的误报
HEARTBEAT_INTERVAL = 180     # 3 分钟

# 从云端拉取用药计划的间隔（秒）
PLAN_SYNC_INTERVAL = 600     # 10 分钟

# 到点后提醒持续多久（秒），超时未确认则本地判定为漏服
REMIND_TIMEOUT = 120         # 2 分钟，与云端 GRACE_MINUTES 保持一致

# 提醒时蜂鸣器响多久、隔多久响一次
BEEP_DURATION_MS = 500
BEEP_GAP_SECONDS = 5

# 时区偏移（北京时间为 UTC+8）
TZ_OFFSET_HOURS = 8
